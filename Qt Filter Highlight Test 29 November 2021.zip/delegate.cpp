#include "delegate.h"
#include <QPainter>
#include <QTextDocument>
#include <QTextCursor>
#include <QAbstractTextDocumentLayout>

Delegate::Delegate(){ selection.setBackground(Qt::green); /*QTextCharFormat*/}
void Delegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const{
    if(index.column() == 6){
        if(option.state & QStyle::State_Selected)
            painter->fillRect(option.rect, Qt::gray);

        QTextDocument doc(index.model()->data(index, Qt::DisplayRole).toString());
        doc.setPageSize(QSizeF(option.rect.width(), option.rect.height()));
        int position = 0;
        QTextCursor cur;
        do {
            cur = doc.find(query, position); // query is private QString
            cur.setCharFormat(selection);
            cur.movePosition(QTextCursor::Right);
            position = cur.position();
        } while (!cur.isNull());
        painter->save();
        painter->translate(option.rect.x(), option.rect.y());
        doc.drawContents(painter);
        painter->restore();
    }
    else QStyledItemDelegate::paint(painter, option, index);
}
