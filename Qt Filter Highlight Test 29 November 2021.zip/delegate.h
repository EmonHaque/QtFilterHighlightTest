#ifndef DELEGATE_H
#define DELEGATE_H

#include <QStyledItemDelegate>
#include <QTextCharFormat>

class Delegate : public QStyledItemDelegate
{
    QString query;
    QTextCharFormat selection;
public:
    Delegate();
    inline void setQuery(const QString& query){ this->query = query; }
    void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
};

#endif // DELEGATE_H
