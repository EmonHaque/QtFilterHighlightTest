#ifndef WINDOW_H
#define WINDOW_H

#include <QWidget>

class QSortFilterProxyModel;
class Delegate;
class Window : public QWidget
{
    Q_OBJECT
    QSortFilterProxyModel *proxy;
    Delegate *delegate;
public:
    Window(QWidget *parent = nullptr);
    ~Window();
};
#endif // WINDOW_H
