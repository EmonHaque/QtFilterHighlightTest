#include "window.h"
#include <QVBoxLayout>
#include <QLineEdit>
#include <QTableView>
#include <QStandardItemModel>
#include <QStandardItem>
#include <QSortFilterProxyModel>
#include <QHeaderView>
#include <QLabel>
#include <QSqlTableModel>
#include <QSql>
#include "delegate.h"

Window::Window(QWidget *parent) : QWidget(parent){
    auto lay = new QVBoxLayout(this);
    auto hlay = new QHBoxLayout;
    auto textBox = new QLineEdit(this);
    auto label = new QLabel(this);
    label->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
    hlay->addWidget(textBox);
    hlay->addWidget(label);
    auto table = new QTableView(this);
    lay->addLayout(hlay);
    lay->addWidget(table);
    auto db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("bukhari.db");
    db.open();
    auto model = new QSqlTableModel;
    model->setTable("Hadith");
    model->select();
    while (model->canFetchMore()) model->fetchMore();
    db.close();
    proxy = new QSortFilterProxyModel(table);
    proxy->setSourceModel(model);
    proxy->setFilterKeyColumn(6);
    table->setModel(proxy);
    delegate = new Delegate();
    table->setItemDelegate(delegate);
    table->verticalHeader()->hide();
    label->setText(locale().toString(proxy->rowCount()));
    connect(textBox, &QLineEdit::textChanged, [=]{
        auto query = textBox->text();
        delegate->setQuery(query);
        proxy->setFilterFixedString(query);
        proxy->invalidate();
        label->setText(locale().toString(proxy->rowCount()));
    });
    table->setVerticalScrollMode(QTableView::ScrollPerPixel);
    table->hideColumn(0);
    table->hideColumn(1);
    table->hideColumn(2);
    table->hideColumn(3);
    table->hideColumn(4);
    table->hideColumn(5);
    table->horizontalHeader()->setStretchLastSection(true);
    table->verticalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
}
Window::~Window(){}

